-------------------------------------------------------------------------------------------------
NextGenSprites
support@next-gen-sprites.com
http://www.wiki.next-gen-sprites.com

-------------------------------------------------------------------------------------------------
Demo Scene Notes
-------------------------------------------------------------------------------------------------
Before you jump into the Demo Scene, please consider that NextGenSprites emission works best 
with HDR and Bloom. Please perform the following steps to get a proper Emission effect:

*	Turn off Anti-Aliasing in Quality Settings
*   Set color space in Player Settings to linear
*	Import Unitys "Effects" standard Assets
*	Open the Demo Scene
*	Add Bloom to the Camera
*	Put Threshold from 0.5 to 1
*	Enjoy!

-------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------
Demo Scene Notes - Dual Material
-------------------------------------------------------------------------------------------------
This Scene shows the effect on lerpting the Dual Material.
Just move the slider around to see the effect.

-------------------------------------------------------------------------------------------------