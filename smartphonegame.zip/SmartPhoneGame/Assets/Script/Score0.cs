﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score0 : MonoBehaviour {
    
	void Start () {
        Battery.seconds1 = 0;
        Battery.seconds2 = 0;
        Battery.seconds3 = 0;
	}

}
